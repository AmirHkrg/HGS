# Changelog

## 1.0.0

- Chess with the full rules: castling, en passant, promotion (to any
  piece), checkmate, stalemate, and automatic draws by threefold
  repetition, the fifty-move rule and insufficient material.
- Two players, or one against the host's bot. The room's options pick the
  bot's level (easy, medium or hard) and who plays white (random, player 1
  or player 2).
- Resigning (on your turn, after a confirmation) and draw offers: one per
  turn, answered by the other side on its turn; moving declines it. The
  bot takes a draw when it stands clearly worse, or late in a level game.
- The board turns to the player's colour and can be flipped; moves are made
  by click, drag or keyboard, with the legal targets shown, the last move
  and a check highlighted, and a promotion picker.
- The moves in algebraic notation, the captured pieces with the material
  lead, and replays move by move.
- English and Persian, light and dark themes.
