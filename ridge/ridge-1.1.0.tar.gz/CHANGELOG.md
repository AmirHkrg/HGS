# Changelog

## 1.1.0

- New physics: the chassis and both wheels are rigid bodies on sliding
  suspensions with stops, the engine and brakes act between wheel and
  chassis (wheelies, nose-dives under braking), tyres grip with friction,
  and traction and wheelie control keep full throttle drivable.
- Your vehicle answers at once: the frontend runs it with the same
  simulation as the server, bit for bit, and corrects itself from the
  server; finish times count each seat's own ticks.
- Four vehicles to pick in the garage before the start: rover, Dirt 250
  (a 250 cc two-stroke motocross bike), dune buggy and monster truck.
- Back flips and front flips score points and a boost; big air scores too.
- Courses with kicks to jump from, no hill steeper than a vehicle can
  climb, and checkpoints with a run-up.
- Records per course, distance and vehicle: best time and stunt score.

## 1.0.0

- Ridge Rider: two to four rovers race over rolling hills in real time, side
  by side without touching. Gas and brake drive on the ground and tip the
  rover in the air; landing on the helmet puts a rover back at its last
  checkpoint (every 50 m). The first over the line wins.
- Three courses (Sunset Dunes, Pine Ridge, and Moon Base with low gravity)
  at 600, 1200 or 2000 m, getting rougher toward the finish.
- The server runs the physics at a fixed 240 Hz step, so a race plays the
  same at any tick rate; bots drive empty seats.
- The frame draws the race on a canvas with parallax backgrounds, dust and
  a HUD (time, place, progress of every rover, speed), in English and
  Persian, with touch pedals, keyboard controls, an engine sound and
  haptics. Each player's best time per course and distance is kept as their
  personal record in the game's per-user storage.
